#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
#include <time.h>
#include <winbase.h>
#include <iostream>

void wait_seconds(double wait_time);
