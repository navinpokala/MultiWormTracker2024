function close_all_figures()

set(0,'ShowHiddenHandles','on');
delete(get(0,'Children'));

return;
end
