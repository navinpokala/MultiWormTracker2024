function [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, output_avi_filename, duration_sec, framerate)
% [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, outputfilename, duration_sec, framerate)


if(nargin==0)
    disp(['Usage: [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, outputfilename, duration_sec, framerate)'])
    disp(['Forces an avi file to be duration_sec seconds long'])
    disp(['framerate is optional; defaults to 3 frames per second'])
    return
end

if(nargin<4)
    framerate=3;
end

numframes = duration_sec*framerate;

% should modify to make grayscale file "hue=s=0" test xvid options

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS" -frames:v %d -r %d -c:v libxvid %s',filename,duration_sec, numframes, framerate, output_avi_filename);

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS" -frames:v %d -r %d -c:v libxvid "hue=s=0" %s',filename,duration_sec, numframes, framerate, output_avi_filename);

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS" -frames:v %d -r %d -c:v mpeg4 "hue=s=0" %s',filename,duration_sec, numframes, framerate, output_avi_filename);

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS" -frames:v %d -r %d -c:v mpeg4 -vtag xvid %s',filename,duration_sec, numframes, framerate, output_avi_filename);

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS , hue=s=0" -frames:v %d -r %d -c:v mpeg4 -vtag xvid %s',filename,duration_sec, numframes, framerate, output_avi_filename);

%% command = sprintf('ffmpeg -i %s -vf "trim=0:%d, setpts=PTS-STARTPTS" -frames:v %d -r %d -c:v mpeg4 %s',filename,duration_sec, numframes, framerate, output_avi_filename);

command = sprintf('ffmpeg -i %s -frames:v %d -r %d -c:v mpeg4 %s',filename,  numframes, framerate, output_avi_filename);



disp(command)
[status, result] = system(command);

return;
end
