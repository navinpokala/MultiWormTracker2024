function tdir = tempdir

tdir = getenv('TEMP');

return;
end
