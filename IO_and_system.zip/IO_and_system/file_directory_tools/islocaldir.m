function islocal = islocaldir(inputname)

if(nargin<1)
    inputname = pwd;
end

islocal = 0;

filename = fullpath_from_filename(inputname);

if(ismac)
    if(isempty(strfind(filename,'Volumes')))
        islocal = 1;
    end
    return;
end


if(~isempty(strfind(filename,'\\mac')) || ~isempty(strfind(filename,'\\Mac')))
    islocal = 1;
    return;
end

if(filename(1)=='\' || filename(1)=='/')
    islocal = 0;
else
    islocal = 1;
end

return;
end
