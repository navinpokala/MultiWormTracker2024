function overlay_images(brightfield_filename, fluorescent_filename, output_filename)

rgb_conv_coef = [0.2989    0.5870    0.1141];

if(nargin<3)
    
    [brightfield_filename, pathname] = uigetfile(...
        {'*.tif;*.tiff;*.png;*.jpeg;*.jpg', 'image Files (*.tif;*.tiff;*.png;*.jpeg;*.jpg)'; '*.*',  'All Files (*.*)' }, ...
        'Select brightfield image');
    
    if(isempty(brightfield_filename))
        errordlg('No image file was selected for analysis');
        return;
    end
    
    brightfield_filename = sprintf('%s%s%s',pathname,brightfield_filename);
    
    
    [fluorescent_filename, pathname] = uigetfile(...
        {'*.tif;*.tiff;*.png;*.jpeg;*.jpg', 'image Files (*.tif;*.tiff;*.png;*.jpeg;*.jpg)'; '*.*',  'All Files (*.*)' }, ...
        'Select fluorescent image');
    
    if(isempty(fluorescent_filename))
        errordlg('No image file was selected for analysis');
        return;
    end
    
    fluorescent_filename = sprintf('%s%s%s',pathname,fluorescent_filename);
    
    output_filename = inputdlg('Outputfile prefix?');
    output_filename = output_filename{1};
end

brightfield = imread(brightfield_filename);
fluorescent = imread(fluorescent_filename);

brightfield_bw = rgb_conv_coef(1)*brightfield(:,:,1) + rgb_conv_coef(2)*brightfield(:,:,2) + rgb_conv_coef(3)*brightfield(:,:,3);
fluorescent_bw = rgb_conv_coef(1)*fluorescent(:,:,1) + rgb_conv_coef(2)*fluorescent(:,:,2) + rgb_conv_coef(3)*fluorescent(:,:,3);

close all

figure(1);
imshow(brightfield_bw); title('brightfield');

figure(2);
imshow(fluorescent_bw); title('fluorescent');

fignum=2;
weights = [0.25 0.5 0.75 1 1.25 1.5 2 2.5 3 5 10 15 20 50 100];
for(i=1:length(weights))
    fignum = fignum+1;
    
    overlay = weight_overlaid_images(brightfield_bw, fluorescent_bw, weights(i));
    
    figure(fignum);
    imshow(overlay)
    title(sprintf('overlay fluor channel weight = %.2f',weights(i)));
    
end

save_pdf(1:fignum, output_filename)


return;
end

function overlay = weight_overlaid_images(brightfield_bw, fluorescent_bw, weight)
 
fluor_subtr = abs(fluorescent_bw-brightfield_bw);

    overlay(:,:,1) = brightfield_bw + weight*fluor_subtr;
    overlay(:,:,2) = brightfield_bw;
    overlay(:,:,3) = brightfield_bw;

return;
end



