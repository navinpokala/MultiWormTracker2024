function cc = bwconncomp_sorted(pix, ascend_flag)
% wrapper for bwconncomp that returns cc sorted by object size 
% default ascending order

% cc = bwconncomp(pix);

% insert bwconncomp and dependent functions to reduce overhead in MATLAB 2024b

size_pix = size(pix);

cc = struct(...
    'Connectivity', 8, ...
    'ImageSize', size_pix, ...
    'NumObjects', [], ...
    'PixelIdxList', []);

[startRow,endRow,startCol,labelForEachRun,i,j] = images.internal.builtins.bwlabel1(pix,8);
if (isempty(labelForEachRun))
    numInitialLabels = 0;
else
    numInitialLabels = max(labelForEachRun);
end
tmp = (1:numInitialLabels)';
A = sparse([i;j;tmp], [j;i;tmp], 1, numInitialLabels, numInitialLabels);
[tmp,p,r] = dmperm(A);
sizes = diff(r);
cc.NumObjects = length(sizes);  
blocks = zeros(1,numInitialLabels);
blocks(r(1:cc.NumObjects)) = 1;
blocks = cumsum(blocks);
blocks(p) = blocks;
labelForEachRun = blocks(labelForEachRun);

runLengths = endRow - startRow + 1;
subs = [labelForEachRun(:), ones(numel(labelForEachRun), 1)];
objectSizes = accumarray(subs, runLengths);
cc.PixelIdxList = images.internal.builtins.pixelIdxLists(size_pix,cc.NumObjects,objectSizes,startRow,...
                             startCol,labelForEachRun,runLengths);

% end insert bwconncomp and dependent functions to reduce overhead


cc.object_sizes=zeros(1,length(cc.PixelIdxList));
for(i=1:length(cc.PixelIdxList))
   cc.object_sizes(i) = length(cc.PixelIdxList{i});
end

if(nargin>1)
    [~, idx] = sort(cc.object_sizes,ascend_flag);
else
    [~, idx] = sort(cc.object_sizes,'ascend');
end

cc.PixelIdxList = cc.PixelIdxList(idx);
cc.object_sizes = cc.object_sizes(idx);

return;
end
