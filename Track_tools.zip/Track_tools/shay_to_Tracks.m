function Tracks = shay_to_Tracks(xy_coords_matrix, worm_image_cell_array, localname, startframe, Width, Height, PixelSize, FrameRate)
% Tracks = shay_to_Tracks(xy_coords_matrix, worm_image_cell_array, localname, startframe, Width, Height, PixelSize, FrameRate)
% Defaults: localname = 'test.avi'; startframe=1; Width = 4096; Height = 2160; PixelSize = 0.01; FrameRate = 3;

if(nargin<2)
   disp('Tracks = shay_to_Tracks(xy_coords_matrix, worm_image_cell_array, localname, startframe, Width, Height, PixelSize, FrameRate)');
   disp('Defaults: localname = ''test.avi''; startframe=1; Width = 4096; Height = 2160; PixelSize = 0.01; FrameRate = 3;');
   return
end

if(nargin<3) 
    localname = 'test.avi';
end
if(nargin<4)
    startframe=1;
end
if(nargin<6)
    Width = 4096;
    Height = 2160;
end
if(nargin<7)
    PixelSize = 0.01;
end
if(nargin<8)
    FrameRate = 3;
end

global Prefs;
Prefs = define_preferences(Prefs);
Prefs.FrameRate = FrameRate;
Prefs = CalcPixelSizeDependencies(Prefs, PixelSize);
Prefs.body_contour_flag = 0;

large_im = rgb2gray(worm_image_cell_array{1});
size_ims = size(large_im);

NumFrames = length(worm_image_cell_array);

rawTracks.NumFrames = NumFrames;
rawTracks.numActiveFrames = rawTracks.NumFrames;

rawTracks.Height = Height;
rawTracks.Width = Width;
rawTracks.PixelSize = PixelSize;
rawTracks.FrameRate = FrameRate;
rawTracks.Name = localname;

rawTracks.RingDistance = zeros(1,NumFrames) + NaN;
rawTracks.original_track_indicies = 1;

rawTracks.Path = xy_coords_matrix;
rawTracks.Frames = [startframe:(startframe+NumFrames-1)];
rawTracks.Time = rawTracks.Frames/FrameRate;

rawTracks.Size = zeros(1,NumFrames) + NaN;
rawTracks.Eccentricity = zeros(1,NumFrames) + NaN;
rawTracks.MajorAxes = zeros(1,NumFrames) + NaN;
rawTracks.bound_box_corner = zeros(NumFrames,2) + NaN;

rawTracks.body_contour = [];
rawTracks.Image = [];

for(m=1:NumFrames)
    
    large_im = rgb2gray(worm_image_cell_array{m});
    thresh = graythresh(large_im);
    bw = ~im2bw(large_im, thresh);
    cc = bwconncomp(bw);
    STATS = custom_regionprops(cc, {'Area', 'Eccentricity', 'MajorAxisLength','Image','BoundingBox'});
    STATS = STATS(1);
    
    STATS.BoundingBox = floor(STATS.BoundingBox);
    
    rawTracks.Image{m} = STATS.Image;
    rawTracks.Size(m) = STATS.Area;
    rawTracks.Eccentricity(m) = STATS.Eccentricity;
    rawTracks.MajorAxes(m) = STATS.MajorAxisLength;
    
    rawTracks.bound_box_corner(m,1) = rawTracks.Path(m,1) - size_ims(2)/2 + STATS.BoundingBox(1);
    rawTracks.bound_box_corner(m,2) = rawTracks.Path(m,2) - size_ims(1)/2 + STATS.BoundingBox(2);
    
    rawTracks.body_contour = [rawTracks.body_contour body_contour_from_image(rawTracks.Image{m}, rawTracks.bound_box_corner(m,:))];
end

Tracks = make_single(AnalyseTrack(rawTracks));


return;
end
