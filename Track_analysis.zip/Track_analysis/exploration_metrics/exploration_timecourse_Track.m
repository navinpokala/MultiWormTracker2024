function Track = exploration_timecourse_Track(inputTrack, binwidth)
% Track = track_exploration_stats(Track, [binwidth])
% binwidth in seconds, default 60
% Track.pathlength = actual distance travelled during the bin (mm)
% Track.path_displacement = distance from start and end of the bin (mm)
% Track.tortuosity = pathlength/path_displacement (unitless)

if(nargin<1)
    disp('usage: Track = exploration_timecourse_Track(Track, [binwidth]), binwidth in sec (default 60)')
    disp('Track.pathlength = actual distance travelled during the bin (mm)')
    disp('Track.path_displacement = distance from start and end of the bin (mm)')
    disp('Track.tortuosity = pathlength/path_displacement (unitless)')
    return
end

if(nargin<2)
    binwidth = 60;
end

Track = inputTrack;

binwidth_frames = binwidth*Track.FrameRate;

Track.pathlength(1:Track.NumFrames)  = NaN;
Track.path_displacement(1:Track.NumFrames)  = NaN;
Track.tortuosity(1:Track.NumFrames)  = NaN;

if(Track.NumFrames < 2*binwidth_frames) % track needs to be at least two binwidth
    return;
end

half_binwidth_frames = floor(binwidth_frames/2);

i = half_binwidth_frames;
start_idx = 1; end_idx = i + half_binwidth_frames;
while(end_idx <= Track.NumFrames)

    Track.pathlength(i) = track_path_length(Track, start_idx, end_idx);
    Track.path_displacement(i) = sqrt((Track.SmoothX(start_idx)-Track.SmoothX(end_idx))^2 + (Track.SmoothY(start_idx)-Track.SmoothY(end_idx))^2);

    Track.tortuosity(i) = Track.pathlength(i)/Track.path_displacement(i);


    i = i+1;
    start_idx = start_idx+1;
    end_idx = end_idx+1;
end

Track.pathlength = Track.pathlength*Track.PixelSize;
Track.path_displacement = Track.path_displacement*Track.PixelSize;

return;
end
