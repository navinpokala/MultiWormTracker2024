function tortuosity_vector = forward_tortuosity_Track(Track)
% pathlength/path_displacement for foward segments of the input Track

tortuosity_vector = [];

fwd_state = num_state_convert('fwd');


if(Track.NumFrames >= 10*Track.FrameRate) % track must be at least 10 sec long
    i=1;
    start_idx = 1; end_idx = 2;
    while(i<Track.NumFrames)
        if(Track.State(i)==fwd_state)
            start_idx = i;
            while(Track.State(i)==fwd_state)
                i=i+1;
                if(i>Track.NumFrames)
                    break;
                end
            end
            end_idx = i-1;
            if(end_idx - start_idx > 10*Track.FrameRate) % forward segment must be at least 10 sec long
                exploration_stats = track_exploration_stats(Track, Track.Time(start_idx), Track.Time(end_idx));
                tortuosity_vector = [tortuosity_vector exploration_stats.tortuosity];
            end
        else
            i=i+1;
        end
    end
end


return;
end
