function [BinData, BinData_2min_bins] = bin_exploration_metrics(inputTracks, stim)

global Prefs; Prefs = define_preferences(Prefs);

% [Tracks, BinData, BinData_2min_bins] = bin_exploration_metrics(inputTracks, stim)
% BinData = [];
% BinData_2min_bins = [];
% 
% % add on pathlength, path_displacement, and tortuosity to Tracks
% for(i=1:length(inputTracks))
%     Tracks(i) = exploration_timecourse_Track(inputTracks(i), 60);
% end
% return;

figure(1);
BinData = bin_and_average_all_tracks(inputTracks); % bin the data
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,1,[0 ceil(max(BinData.time)) 0 max(BinData.Rev_freq + BinData.Rev_freq_err)],'Rev_freq','k','10sec bin','Rev_freq');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,2,[0 ceil(max(BinData.time)) 1 max(BinData.tortuosity + BinData.tortuosity_err)],'tortuosity','k','1sec bin','tortuosity');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,3,[0 ceil(max(BinData.time)) 0 max(BinData.speed + BinData.speed_err)],'speed','k','1sec bin','speed');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,4,[0 ceil(max(BinData.time)) 0 max(BinData.frac_pause + BinData.frac_pause_err)],'frac_pause','k','1sec bin','frac_pause');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,5,[0 ceil(max(BinData.time)) 0 max(BinData.curv + BinData.curv_err)],'curv','k','1sec bin','curv');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,6,[0 ceil(max(BinData.time)) 0 max(BinData.path_displacement + BinData.path_displacement_err)],'path_displacement','k','1sec bin','path_displacement');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,7,[0 ceil(max(BinData.time)) floor(min(BinData.body_angle - BinData.body_angle_err)) ceil(max(BinData.body_angle + BinData.body_angle_err))],'body_angle','k','1sec bin','body_angle');
errorshade_stimshade_lineplot_BinData(BinData, stim, 4,2,8,[0 ceil(max(BinData.time)) (min(BinData.ecc - BinData.ecc_err)) (max(BinData.ecc + BinData.ecc_err))],'ecc','k','1sec bin','ecc');

figure(2);
BinData_2min_bins = alternate_binwidth_BinData(BinData, 120); % re-bin everything with 2 min bins
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,1,[0 ceil(max(BinData_2min_bins.time)) 0 max(BinData_2min_bins.Rev_freq + BinData_2min_bins.Rev_freq_err)],'Rev_freq','k','2min bin','Rev_freq');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,2,[0 ceil(max(BinData_2min_bins.time)) 1 max(BinData_2min_bins.tortuosity + BinData_2min_bins.tortuosity_err)],'tortuosity','k','2min bin','tortuosity');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,3,[0 ceil(max(BinData_2min_bins.time)) 0 max(BinData_2min_bins.speed + BinData_2min_bins.speed_err)],'speed','k','2min bin','speed');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,4,[0 ceil(max(BinData_2min_bins.time)) 0 max(BinData_2min_bins.frac_pause + BinData_2min_bins.frac_pause_err)],'frac_pause','k','2min bin','frac_pause');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,5,[0 ceil(max(BinData_2min_bins.time)) 0 max(BinData_2min_bins.curv + BinData_2min_bins.curv_err)],'curv','k','2min bin','curv');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,6,[0 ceil(max(BinData_2min_bins.time)) 0 max(BinData_2min_bins.path_displacement + BinData_2min_bins.path_displacement_err)],'path_displacement','k','2min bin','path_displacement');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,7,[0 ceil(max(BinData_2min_bins.time)) floor(min(BinData_2min_bins.body_angle - BinData_2min_bins.body_angle_err)) ceil(max(BinData_2min_bins.body_angle + BinData_2min_bins.body_angle_err))],'body_angle','k','2min bin','body_angle');
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,2,8,[0 ceil(max(BinData_2min_bins.time)) (min(BinData_2min_bins.ecc - BinData_2min_bins.ecc_err)) (max(BinData_2min_bins.ecc + BinData_2min_bins.ecc_err))],'ecc','k','2min bin','ecc');

figure(3);
BinData_10sec_bins = alternate_binwidth_BinData(BinData, 10); % re-bin everything with 10 sec bins
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,1,[0 ceil(max(BinData_10sec_bins.time)) 0 max(BinData_10sec_bins.Rev_freq + BinData_10sec_bins.Rev_freq_err)],'Rev_freq','k','10sec bin','Rev_freq');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,2,[0 ceil(max(BinData_10sec_bins.time)) 1 max(BinData_10sec_bins.tortuosity + BinData_10sec_bins.tortuosity_err)],'tortuosity','k','10sec bin','tortuosity');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,3,[0 ceil(max(BinData_10sec_bins.time)) 0 max(BinData_10sec_bins.speed + BinData_10sec_bins.speed_err)],'speed','k','10sec bin','speed');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,4,[0 ceil(max(BinData_10sec_bins.time)) 0 max(BinData_10sec_bins.frac_pause + BinData_10sec_bins.frac_pause_err)],'frac_pause','k','10sec bin','frac_pause');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,5,[0 ceil(max(BinData_10sec_bins.time)) 0 max(BinData_10sec_bins.curv + BinData_10sec_bins.curv_err)],'curv','k','10sec bin','curv');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,6,[0 ceil(max(BinData_10sec_bins.time)) 0 max(BinData_10sec_bins.path_displacement + BinData_10sec_bins.path_displacement_err)],'path_displacement','k','10sec bin','path_displacement');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,7,[0 ceil(max(BinData_10sec_bins.time)) floor(min(BinData_10sec_bins.body_angle - BinData_10sec_bins.body_angle_err)) ceil(max(BinData_10sec_bins.body_angle + BinData_10sec_bins.body_angle_err))],'body_angle','k','10sec bin','body_angle');
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,2,8,[0 ceil(max(BinData_10sec_bins.time)) (min(BinData_10sec_bins.ecc - BinData_10sec_bins.ecc_err)) (max(BinData_10sec_bins.ecc + BinData_10sec_bins.ecc_err))],'ecc','k','10sec bin','ecc');


figure(4);
BinData_1min_bins = alternate_binwidth_BinData(BinData, 60); % re-bin everything with 1 min bins
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,1,[0 ceil(max(BinData_1min_bins.time)) 0 max(BinData_1min_bins.Rev_freq + BinData_1min_bins.Rev_freq_err)],'Rev_freq','k','1min bin','Rev_freq');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,2,[0 ceil(max(BinData_1min_bins.time)) 1 max(BinData_1min_bins.tortuosity + BinData_1min_bins.tortuosity_err)],'tortuosity','k','1min bin','tortuosity');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,3,[0 ceil(max(BinData_1min_bins.time)) 0 max(BinData_1min_bins.speed + BinData_1min_bins.speed_err)],'speed','k','1min bin','speed');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,4,[0 ceil(max(BinData_1min_bins.time)) 0 max(BinData_1min_bins.frac_pause + BinData_1min_bins.frac_pause_err)],'frac_pause','k','1min bin','frac_pause');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,5,[0 ceil(max(BinData_1min_bins.time)) 0 max(BinData_1min_bins.curv + BinData_1min_bins.curv_err)],'curv','k','1min bin','curv');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,6,[0 ceil(max(BinData_1min_bins.time)) 0 max(BinData_1min_bins.path_displacement + BinData_1min_bins.path_displacement_err)],'path_displacement','k','1min bin','path_displacement');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,7,[0 ceil(max(BinData_1min_bins.time)) floor(min(BinData_1min_bins.body_angle - BinData_1min_bins.body_angle_err)) ceil(max(BinData_1min_bins.body_angle + BinData_1min_bins.body_angle_err))],'body_angle','k','1min bin','body_angle');
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,2,8,[0 ceil(max(BinData_1min_bins.time)) (min(BinData_1min_bins.ecc - BinData_1min_bins.ecc_err)) (max(BinData_1min_bins.ecc + BinData_1min_bins.ecc_err))],'ecc','k','1min bin','ecc');

end



errorshade_stimshade_lineplot_BinData(BinData, stim, 4,1,1,[0 ceil(max(BinData.time)) min(BinData.pathlength - BinData.pathlength_err) max(BinData.pathlength + BinData.pathlength_err)],'pathlength','k','10sec bin','pathlength');

BinData_10sec_bins = alternate_binwidth_BinData(BinData, 10); % re-bin everything with 10 sec bins
errorshade_stimshade_lineplot_BinData(BinData_10sec_bins, stim, 4,1,2,[0 ceil(max(BinData_10sec_bins.time)) min(BinData_10sec_bins.pathlength - BinData_10sec_bins.pathlength_err) max(BinData_10sec_bins.pathlength + BinData_10sec_bins.pathlength_err)],'pathlength','k','10sec bin','pathlength');

BinData_1min_bins = alternate_binwidth_BinData(BinData, 60); % re-bin everything with 1 min bins
errorshade_stimshade_lineplot_BinData(BinData_1min_bins, stim, 4,1,3,[0 ceil(max(BinData_1min_bins.time)) min(BinData_1min_bins.pathlength - BinData_1min_bins.pathlength_err) max(BinData_1min_bins.pathlength + BinData_1min_bins.pathlength_err)],'pathlength','k','1min bin','pathlength');

BinData_2min_bins = alternate_binwidth_BinData(BinData, 120); % re-bin everything with 2 min bins
errorshade_stimshade_lineplot_BinData(BinData_2min_bins, stim, 4,1,4,[0 ceil(max(BinData_2min_bins.time)) min(BinData_2min_bins.pathlength - BinData_2min_bins.pathlength_err) max(BinData_2min_bins.pathlength + BinData_2min_bins.pathlength_err)],'pathlength','k','2min bin','pathlength');


