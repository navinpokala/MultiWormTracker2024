function Image = body_contour_to_image(body_contour, height, width)

im = logical(zeros(height,width));

for(i=1:length(body_contour.x))
    im(body_contour.y(i),body_contour.x(i))=1;
end

Image = im(min(body_contour.y):max(body_contour.y), min(body_contour.x):max(body_contour.x));

return;
end
