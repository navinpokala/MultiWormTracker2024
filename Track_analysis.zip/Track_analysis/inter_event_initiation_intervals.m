function  interval_vector = inter_event_initiation_intervals(Tracks, eventtype)

% find times between event initiations

return;

end 
