function [score, num_objects, num_worms]  = chemotaxis_worm_thresh_score(level, im, MaxWormArea, MinWormArea)

    BW = im2bw(im, level);
    L = bwlabel(~BW); 

    objects = regionprops(L, {'Area'});

    num_objects = length(objects);
    areas=[];
    for(i=1:num_objects)
        areas =[areas objects(i).Area];
    end
    

    num_worms = length(find(areas<=MaxWormArea & areas>=MinWormArea));

    if(num_objects > 0)
        if(num_worms > 0)
            score = num_objects/num_worms;
        else
            score = 1000*num_objects;
        end
    else
        score = 1000;
    end
    
%     if(num_worms > 0)
%        disp([level score num_objects num_worms])
%        imshow(BW); 
%        pause;
% %        pause(0.1);
%         close all
%     end
    
    clear('BW'); clear('L'); clear('objects');
    
return;
end