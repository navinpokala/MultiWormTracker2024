function [best_level, best_score] = find_optimal_threshold_endpoint_chemotaxis(im, MaxWormArea, MinWormArea)


     best_level = fminbnd(@(best_level) chemotaxis_worm_thresh_score(best_level, im, MaxWormArea, MinWormArea),0.01,0.8);
     [best_score, num_obj, num_worm] = chemotaxis_worm_thresh_score(best_level, im, MaxWormArea, MinWormArea);
         
    if(best_score >= 1000)
       
        for(level = 0.01:0.01:0.8)
            [score, num_obj, num_worm] = chemotaxis_worm_thresh_score(level, im, MaxWormArea, MinWormArea);
            if(score < best_score)
                best_score = score;
                best_level = level;
            end
        end
        
    end
    
return;
end