function chemotaxis_frame_out = chemotaxis_index_movie_frames(MovieName, varargin)

global Prefs;
Prefs = [];
Prefs = define_preferences(Prefs);

close all

% some default values
maxclump =  10;
min_ecc = 0.4;
MinWormArea_mm = ((1/2)*1)*((1/2)*0.1); % ((2/3)*1)*((2/3)*0.1);
MaxWormArea_mm = ((3/2)*1)*((3/2)*0.1); % ((4/3)*1)*((4/3)*0.1);
MinWormLength_mm = 0.25; % 0.5;
target_zone_distance_mm = 15;

chemotaxis_frame_out = [];

pixelsize = 0.0423; % 600 dpi
pixelsize = 97/(3118-228);

FileInfo = moviefile_info(MovieName);
startFrame = 1;
endFrame = FileInfo.NumFrames;

i=1;
if(nargin>1)
    if(~isempty(strfind(varargin{i},'pixel')))
        i=i+1;
        if(ischar(varargin{i}))
            Ring = get_pixelsize_from_arbitrary_object(varargin{i});
            pixelsize = Ring.PixelSize;
            clear('Ring');
        else
            pixelsize = varargin{i};
        end
        i=i+1;
    else if(isnumeric(varargin{i})) % frame range
            startFrame = varargin{i}(1);
            endFrame = varargin{i}(2);
            if(endFrame > FileInfo.NumFrames)
                endFrame = FileInfo.NumFrames;
            end
            i=i+1;
        end
    end
end

Mov = aviread_to_gray(MovieName,endFrame);
im_in = Mov.cdata;
    im_in = 1- (255-double(im_in))./255;

clear('Mov');
clear('FileInfo');

if(isempty(pixelsize))
    Ring = get_pixelsize_from_arbitrary_object(MovieName);
    pixelsize = Ring.PixelSize;
    clear('Ring');
end


MinWormArea = MinWormArea_mm/(pixelsize^2);
MaxWormArea = MaxWormArea_mm/(pixelsize^2);
MinWormLength = MinWormLength_mm/(pixelsize);
maxclump_area = maxclump*MaxWormArea;
maxclump_area_4 = 4*maxclump_area;

% find arena edges and block out with mask arena_mask

questdlg('Identify verticies of the region of interest, then double-click','OK','OK');
h_im = imshow(im_in);
e = impoly(gca);

arena_mask = double(createMask(e,h_im));

im = double(im_in).*arena_mask;

% identfy odor1 and odor2 points
close all;
odor1 = zeros(1,2);
odor2 = odor1;

imshow(im);
questdlg(sprintf('Select odor1\nHit return.'), 'Odor1 identification', 'OK', 'OK');

[odor1(1), odor1(2)] = ginput2('.b','markersize',30);
hold on
plot(odor1(1), odor1(2), '.b','markersize',30);

a = questdlg(sprintf('Select odor2 or control.\nHit return.'), 'Odor2/control source identification', 'OK', 'OK');
if(a(1)=='O')
    [odor2(1), odor2(2)] = ginput2('.r','markersize',30);
    
    hold on
    plot(odor1(1), odor1(2), '.b','markersize',30);
    plot(odor2(1), odor2(2), '.r','markersize',30);
end
close all;


% loop through frames

for(frame = startFrame:endFrame)
    
    fprintf('Frame %d looking for worms ...\n',frame);
    
    Mov = aviread_to_gray(MovieName,frame);
    im_in = Mov.cdata;
    im_in = 1- (255-double(im_in))./255;
    clear('Mov');

    im = im_in.*arena_mask;
    
    % threshold level
    level = find_optimal_threshold_endpoint_chemotaxis(im, MaxWormArea, MinWormArea);
    disp('getting stats for worm objects ....')
    
    % create binary image bitmap
    BW = im2bw(im, level);
    
    % extract info for each object in the bitmap
    L = bwlabel(~BW);
    clear('BW');
    
    objects = regionprops(L, {'Area','Centroid','MajorAxisLength','Eccentricity','BoundingBox'});
    
    % remove objects that are clearly not worms

    sprintf('num_objects = %d',length(objects))
    
    i=1; intens=[]; 
    while(i<=length(objects))
        if(objects(i).Area < MinWormArea || objects(i).Eccentricity < min_ecc || objects(i).Eccentricity > 0.99 || ...
                objects(i).Area > maxclump_area || objects(i).BoundingBox(3)*objects(i).BoundingBox(4) > maxclump_area_4)
            objects(i) = [];
        else
            intens = [intens mean_object_intensity(objects(i), im, level)];
            i=i+1;
        end
    end
    
    % get areas  and intensities of isolated worms
    worm_intens=[]; worm_areas=[];
    for(i=1:length(objects))
        if(objects(i).Area<=MaxWormArea && objects(i).Area>=MinWormArea && objects(i).MajorAxisLength>=MinWormLength)
            worm_intens = [worm_intens intens(i)];
            worm_areas = [worm_areas objects(i).Area];
        end
    end
    min_intens = min(worm_intens);
    max_intens = max(worm_intens);
    mean_intens = (nanmean(worm_intens) + nanmedian(worm_intens))/2;
    std_intens = nanstd(worm_intens);
    mean_worm_area = (mean(worm_areas) + median(worm_areas))/2;
    
    sprintf('num_worm_sized_objects = %d',length(worm_areas))
    
    objects = [];
    
    % extract info for each object in the bitmap
    objects = regionprops(L, {'Area','Centroid','MajorAxisLength','Eccentricity','BoundingBox'});
    
    rejected_objects = [];
    
    disp('removing non-worm objects ....')
    
    % remove objects that are clearly not worms
    i=1;
    while(i<=length(objects))
        if(objects(i).Area < MinWormArea || objects(i).Eccentricity < min_ecc || objects(i).Eccentricity > 0.99 || ...
                objects(i).Area > maxclump_area || objects(i).BoundingBox(3)*objects(i).BoundingBox(4) > maxclump_area_4)
            rejected_objects = [rejected_objects objects(i)];
            objects(i) = [];
        else
            i=i+1;
        end
    end
            
   % find objects that have the dimensions and intensity of a standard worm

   obj_indices=[];
   num_worms=[];
   worm_density=[];
   for(i=1:length(objects))
       if(objects(i).Area<=MaxWormArea && objects(i).Area>=MinWormArea && objects(i).MajorAxisLength>=MinWormLength ...
               && intens(i) >= min_intens && intens(i) <= max_intens )
           obj_indices=[obj_indices i];
           num_worms = [num_worms max(1,(objects(i).Area/mean_worm_area))];
           worm_density = [worm_density max(1,(objects(i).Area/mean_worm_area))/(objects(i).BoundingBox(3)*objects(i).BoundingBox(4))];
           
       end
   end
   worm_density_cutoff =  max(worm_density); % nanmedian(worm_density) + nanstd(worm_density); %
    
    % find remaining objects that may contain clumps of worms
    for(i=1:length(objects))
        if(isempty(find(obj_indices == i)))
            if(objects(i).Area > MaxWormArea && objects(i).MajorAxisLength>=MinWormLength)
                clump_size = (objects(i).Area/mean_worm_area);
                if(clump_size <= maxclump)
%                 if(clump_size <= maxclump && clump_size/(objects(i).BoundingBox(3)*objects(i).BoundingBox(4)) <= worm_density_cutoff ...
%                         && intens(i) >= min_intens && intens(i) <= max_intens )
%                         % && intens(i) <= (mean_intens + std_intens) && intens(i) >= (mean_intens - std_intens) )
                    num_worms = [num_worms clump_size];
                    obj_indices = [obj_indices i];
                end
            end
        end
    end
    
    [p,idx] = sort(obj_indices);
    obj_indices = obj_indices(idx);
    num_worms = num_worms(idx);
    
    % remove objects not assigned as worm(s)
    i=1;
    del_idx=[];
    while(i<=length(objects))
        if(isempty(find(obj_indices == i)))
            del_idx = [del_idx i];
            rejected_objects = [rejected_objects objects(i)];
        end
        i=i+1;
    end
    objects(del_idx) = [];
    intens(del_idx) = [];
    clear('obj_indices');
    
    close all;
    
    % manually check worms
    
    view_picked_worms(objects, [], num_worms, im, rejected_objects);
    hold on
    yep=1;
    for(i=1:length(num_worms))
        if(num_worms(i)>4 || num_worms(i)<0.5 || num_worms(i)/(objects(i).BoundingBox(3)*objects(i).BoundingBox(4)) > worm_density_cutoff)
            if(yep==1)
                disp(['You may want to double-check the green objects in particular!'])
                yep=0;
            end
            rectangle('Position',objects(i).BoundingBox,'EdgeColor','g');
        end
    end
    
    % manually add worms
    % pick centroid of region, assume box size of average box dimensions, count
    % worms via area, else one
    
    answer = questdlg('Add/remove additional worms?', 'Add/remove worms', 'Yes', 'No', 'Yes');
    yep=1;
    while(answer(1)=='Y')
        
        if(yep==1)
            disp('Pick animal(s) of interest to add ...');
            disp('Click inside square(s) of interest to delete ...');
            yep=0;
        end
        [objects, num_worms, intens] = add_delete_worms_with_mouse(im, objects, num_worms, intens);
        
        view_picked_worms(objects, [], num_worms, im, rejected_objects);
        answer = questdlg('Add/remove additional worms/objects?', 'Add/remove worms', 'Yes', 'No', 'Yes');
        
    end
    close all
    
    total_worms = ceil(sum(num_worms));
    
    chemotaxis_frame.frame = frame;
    chemotaxis_frame.num_worms_odor1 = 0;
    chemotaxis_frame.num_worms_odor2 = 0;
    
    del_idx=[];
    for(i=1:length(objects))
        chemotaxis_frame.objects(i).coords = objects(i).Centroid;
        chemotaxis_frame.objects(i).mean_intensity = intens(i);
        chemotaxis_frame.objects(i).worm_area = objects(i).Area;
        chemotaxis_frame.objects(i).BoundingBox = objects(i).BoundingBox;
        chemotaxis_frame.objects(i).num_worms = max(1,num_worms(i));
        
        
        chemotaxis_frame.objects(i).r1 = sqrt((chemotaxis_frame.objects(i).coords(1) - odor1(1))^2 + (chemotaxis_frame.objects(i).coords(2) - odor1(2))^2);
        chemotaxis_frame.objects(i).r2 = sqrt((chemotaxis_frame.objects(i).coords(1) - odor2(1))^2 + (chemotaxis_frame.objects(i).coords(2) - odor2(2))^2);
        
        if(chemotaxis_frame.objects(i).r1 <= target_zone_distance_mm/pixelsize)
            chemotaxis_frame.num_worms_odor1 = chemotaxis_frame.num_worms_odor1 + chemotaxis_frame.objects(i).num_worms;
        end
        if(chemotaxis_frame.objects(i).r2 <= target_zone_distance_mm/pixelsize)
            chemotaxis_frame.num_worms_odor2 = chemotaxis_frame.num_worms_odor2 + chemotaxis_frame.objects(i).num_worms;
        end
        
    end
    if(~isempty(del_idx))
        chemotaxis_frame.objects(del_idx)=[];
    end
    
    
    close all;
    
    chemotaxis_frame.num_worms_odor1 = ceil(chemotaxis_frame.num_worms_odor1);
    chemotaxis_frame.num_worms_odor2 = ceil(chemotaxis_frame.num_worms_odor2);
    
    h=view_picked_worms(objects, [], num_worms, im_in, rejected_objects);
    
    hold on;
    plot(odor1(1), odor1(2), 'ob');
    plot(odor2(1), odor2(2), 'or');
    
    [x,y] = coords_from_circle_params(target_zone_distance_mm/pixelsize, [odor1(1) odor1(2)] );
    plot(x,y,'b');
    [x,y] = coords_from_circle_params(target_zone_distance_mm/pixelsize, [odor2(1) odor2(2)] );
    plot(x,y,'r');
    
    CI = ((chemotaxis_frame.num_worms_odor1) - (chemotaxis_frame.num_worms_odor2))/((chemotaxis_frame.num_worms_odor1) + (chemotaxis_frame.num_worms_odor2));
    chemotaxis_frame.CI = CI;
    ts = sprintf('Frame %d CI_odor1 = %f\n odor1 = %d   odor2 = %d   neutral = %d',frame, CI, (chemotaxis_frame.num_worms_odor1), (chemotaxis_frame.num_worms_odor2), (total_worms-(chemotaxis_frame.num_worms_odor1 + chemotaxis_frame.num_worms_odor2)));
    disp(ts);
    
    platename = sprintf('Frame_%d',frame);
    
    title(fix_title_string(sprintf('%s',ts)));
    orient portrait; % landscape
    % save_pdf(h,platename);
    saveas(gcf,sprintf('%s.tif',platename));
    
    chemotaxis_frame_out = [chemotaxis_frame_out chemotaxis_frame];
    clear('chemotaxis_frame');
    
end



return;
end
